package com.simplilearn.mediCare.config;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.simplilearn.mediCare.entities.Cart;
import com.simplilearn.mediCare.user.User1;

//@SpringBootConfiguration
public class ConfigBean {
	/*
	 * @Bean("User12") public static User1 getUser1() { User1 user1=new User1();
	 * user1.setCart(new Cart()); return user1; }
	 */
}
