package com.simplilearn.mediCare;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.simplilearn.mediCare.user.User1;

@SpringBootApplication
public class MedicareApplication implements CommandLineRunner{

	@Autowired
	User1 user1;
	
	public static void main(String[] args) {
		SpringApplication.run(MedicareApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println(user1);
		user1.setName("Bhuwan");
		System.out.println(user1);

		
		
	}
	

}
