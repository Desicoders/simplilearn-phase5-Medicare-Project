package com.simplilearn.kitchenStory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KitchenStoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
